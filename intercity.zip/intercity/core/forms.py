import datetime
from django import forms
#from django.contrib.admin.widgets import AdminDateWidget
#from django.forms.fields import DateField
from .models import *
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit, Row, Column, Fieldset, MultiField

class DateInput(forms.DateInput):
    input_type = 'date'

class VehicleForm(forms.ModelForm):
    class Meta:
        model = Vehicle
        fields = '__all__'

    def clean(self):
        # data from the form is fetched using super function
        super(VehicleForm, self).clean()

        # return any errors if found
        return self.cleaned_data
    
class PlaceForm(forms.ModelForm):
    class Meta:
        model = Place
        fields = '__all__'

    def clean(self):
        # data from the form is fetched using super function
        super(PlaceForm, self).clean()

        # return any errors if found
        return self.cleaned_data
    
class TripForm(forms.ModelForm):
    class Meta:
        model = Trip
        fields = '__all__'

    def clean(self):
        # data from the form is fetched using super function
        super(TripForm, self).clean()

        # return any errors if found
        return self.cleaned_data
    
class RateForm(forms.ModelForm):
    class Meta:
        model = Rate
        fields = '__all__'

    def clean(self):
        # data from the form is fetched using super function
        super(RateForm, self).clean()

        # return any errors if found
        return self.cleaned_data
    
class DiscountForm(forms.ModelForm):
    class Meta:
        model = Discount
        fields = '__all__'

    eff_from = forms.DateField(widget=DateInput)
    eff_till = forms.DateField(widget=DateInput)

    def clean(self):
        # data from the form is fetched using super function
        super(DiscountForm, self).clean()

        # return any errors if found
        return self.cleaned_data
    
class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = '__all__'

    def clean(self):
        # data from the form is fetched using super function
        super(CustomerForm, self).clean()

        # return any errors if found
        return self.cleaned_data
    
class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        # fields = ('customer', 'vehicle', 'trip', 'journey_date', 'status', 'paid')
        fields = '__all__'
        widgets = {'status': forms.HiddenInput(), 'paid': forms.HiddenInput()}

    journey_date = forms.DateField(widget=DateInput)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Row(
                Column(
                    Fieldset('1.1', 'customer', 'vehicle', 'trip', 'journey_date', 'status', 'paid'), 
                    css_class = 'form-group col col-md-6'
                ),
                Column(
                    Fieldset('1.2', 'driver_name', 'driver_contact', 'vehicle_number'),
                    css_class = 'form-group col col-md-2'
                ),
                css_class = 'form-row'
            ),
            Row(
                Column(
                    Fieldset('2.1', 'paymode', 'payref', 'paid'),
                    css_class = 'form-group col col-md-2'
                ),
                Column(
                    Fieldset('2.2', 'baserate', 'discount', 'surcharge', 'cgst', 'sgst', 'amount'),
                    css_class = 'form-group col col-md-2'
                ),
                css_class='form-row'
            ),
        )
    
    def clean(self):
        # data from the form is fetched using super function
        super(BookingForm, self).clean()

        # return any errors if found
        return self.cleaned_data

class ServiceForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ('driver_name', 'driver_contact', 'vehicle_number', 'status')
        widgets = {'status': forms.HiddenInput()}

    def clean(self):
        # data from the form is fetched using super function
        super(ServiceForm, self).clean()

        # return any errors if found
        return self.cleaned_data
    
class PaymentForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ('paymode', 'payref', 'paid', 'status')
        widgets = {'status': forms.HiddenInput()}

    def clean(self):
        # data from the form is fetched using super function
        super(PaymentForm, self).clean()

        # return any errors if found
        return self.cleaned_data
    
class InvoiceForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ('baserate', 'discount', 'surcharge', 'cgst', 'sgst', 'amount', 'status')
        widgets = {'status': forms.HiddenInput()}

    def clean(self):
        # data from the form is fetched using super function
        super(InvoiceForm, self).clean()

        # return any errors if found
        return self.cleaned_data