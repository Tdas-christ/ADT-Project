from django.shortcuts import render, redirect
from django.views import View
from django.views.generic import TemplateView
from django.template import loader
from django.http import HttpResponse
from .models import *
from .forms import *
from django.contrib import messages
from django.contrib.auth import authenticate,login

# Create your views here.

def signup(request):
    if request.method == 'POST':
        # Get the form data from the request
        name = request.POST.get('Name')
        email = request.POST.get('email')
        phone_number = request.POST.get('phone')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # Check if a user with this email already exists
        if User.objects.filter(email=email).exists():
            messages.error(request, "An account with this email already exists.")
            return redirect('signup')
        #If passwords don't match
        if password!=confirm_password:
            messages.error(request,"Passwords do not match.")
            return redirect('signup')
        # Create a new Customer object with the form data
        user = User(name=name, email=email, phone_number=phone_number)
        # Set the password using the set_password method
        user.set_password(password)
        # Save the Customer object to the database
        user.save()
        #return redirect(request, 'login')
        # Authenticate the user and log them in
        user = authenticate(request, username=email, password=password)
        #login(request, user)
        if user is not None:
            login(request, user)
            # Redirect the user to a thank-you page
            return redirect(request, 'booking')
        #else:
            ## If authentication fails, display an error message
            #messages.error(request, 'Invalid email or password.')
            #return redirect('signup')
        return redirect('booking')

    # Render the signup form for GET requests
    return render(request, 'signup.html')
        
def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        if User.objects.filter(email=email).exists():
            messages.error(request, 'Logged in successfully!')
            # Redirect the user to a thank-you page
            return redirect('booking')

        else:
            # User does not exist, return error message
                #messages.error(request, f'entred inside else {user}')
            messages.error(request, 'You are not Signed In!')
            return render(request, 'login.html', {'error': 'You are not Signed In!'})
    return render(request, 'login.html') 


class VehicleListView(TemplateView):
    def get(self, request):
        pageinfo = {'title': 'Vehicle', 'edituri': 'vehicle-edit', 'datauri': 'vehicle-data'}
        context = {'pageinfo': pageinfo, 'list': Vehicle.objects.all()}
        return render(request=request,template_name=self.template_name, context=context)
    
class VehicleView(View):
    def get(self, request):
        form = None
        try:
            form = VehicleForm(instance=Vehicle.objects.get(id=request.GET['id']))
        except:
            form = VehicleForm()

        context = {'form': form}
        return render(request=request,template_name="view_form.html", context=context)
        
    def post(self, request):
        form = None
        try:
            form = VehicleForm(request.POST, instance=Vehicle.objects.get(id=request.GET['id']))
        except:
            form = VehicleForm(request.POST)

        if form.is_valid():
            form.save()
            return HttpResponse(status=204, headers={'HX-Trigger': 'listChanged'})
        
        #redirect('intercity/vehicle/list')

        context={'form':form}
        return render(request=request, template_name="view_form.html", context=context)

class PlaceListView(TemplateView):
    def get(self, request):
        pageinfo = {'title': 'Place', 'edituri': 'place-edit', 'datauri': 'place-data'}
        context = {'pageinfo': pageinfo, 'list': Place.objects.all()}
        return render(request=request,template_name=self.template_name, context=context)
        
class PlaceView(View):
    def get(self, request):
        form = None
        try:
            form = PlaceForm(instance=Place.objects.get(id=request.GET['id']))
        except:
            form = PlaceForm()

        context = {'form': form}
        return render(request=request,template_name="view_form.html", context=context)
        
    def post(self, request):
        form = None
        try:
            form = PlaceForm(request.POST, instance=Place.objects.get(id=request.GET['id']))
        except:
            form = PlaceForm(request.POST)

        if form.is_valid():
            form.save()
            return HttpResponse(status=204, headers={'HX-Trigger': 'listChanged'})

        context={'form':form}
        return render(request=request, template_name="view_form.html", context=context)

class TripListView(TemplateView):
    def get(self, request):
        pageinfo = {'title': 'Journeys', 'edituri': 'trip-edit', 'datauri': 'trip-data'}
        context = {'pageinfo': pageinfo, 'list': Trip.objects.all()}
        return render(request=request,template_name=self.template_name, context=context)
    
class TripView(View):
    def get(self, request):
        form = None
        try:
            form = TripForm(instance=Trip.objects.get(id=request.GET['id']))
        except:
            form = TripForm()

        context = {'form': form}
        return render(request=request,template_name="view_form.html", context=context)
        
    def post(self, request):
        form = None
        try:
            form = TripForm(request.POST, instance=Trip.objects.get(id=request.GET['id']))
        except:
            form = TripForm(request.POST)

        if form.is_valid():
            form.save()
            return HttpResponse(status=204, headers={'HX-Trigger': 'listChanged'})

        context={'form':form}
        return render(request=request, template_name="view_form.html", context=context)

class RateListView(TemplateView):
    def get(self, request):
        pageinfo = {'title': 'Rate', 'edituri': 'rate-edit', 'datauri': 'rate-data'}
        context = {'pageinfo': pageinfo, 'list': Rate.objects.all()}
        return render(request=request,template_name=self.template_name, context=context)
    
class RateView(View):
    def get(self, request):
        form = None
        try:
            form = RateForm(instance=Rate.objects.get(id=request.GET['id']))
        except:
            form = RateForm()

        context = {'form': form}
        return render(request=request,template_name="view_form.html", context=context)
        
    def post(self, request):
        form = None
        try:
            form = RateForm(request.POST, instance=Rate.objects.get(id=request.GET['id']))
        except:
            form = RateForm(request.POST)

        if form.is_valid():
            form.save()
            return HttpResponse(status=204, headers={'HX-Trigger': 'listChanged'})

        context={'form':form}
        return render(request=request, template_name="view_form.html", context=context)
    
class DiscountListView(TemplateView):
    def get(self, request):
        pageinfo = {'title': 'Discount', 'edituri': 'discount-edit', 'datauri': 'discount-data'}
        context = {'pageinfo': pageinfo, 'list': Discount.objects.all()}
        return render(request=request,template_name=self.template_name, context=context)
    
class DiscountView(View):
    def get(self, request):
        form = None
        try:
            form = DiscountForm(instance=Discount.objects.get(id=request.GET['id']))
        except:
            form = DiscountForm()

        context = {'form': form}
        return render(request=request,template_name="view_form.html", context=context)
        
    def post(self, request):
        form = None
        try:
            form = DiscountForm(request.POST, instance=Discount.objects.get(id=request.GET['id']))
        except:
            form = DiscountForm(request.POST)

        if form.is_valid():
            form.save()
            return HttpResponse(status=204, headers={'HX-Trigger': 'listChanged'})

        context={'form':form}
        return render(request=request, template_name="view_form.html", context=context)

class CustomerListView(TemplateView):
    def get(self, request):
        pageinfo = {'title': 'Customer', 'edituri': 'customer-edit', 'datauri': 'customer-data'}
        context = {'pageinfo': pageinfo, 'list': Customer.objects.all()}
        return render(request=request,template_name=self.template_name, context=context)
    
class CustomerView(View):
    def get(self, request):
        form = None
        try:
            form = CustomerForm(instance=Customer.objects.get(id=request.GET['id']))
        except:
            form = CustomerForm()

        context = {'form': form}
        return render(request=request,template_name="view_form.html", context=context)
        
    def post(self, request):
        form = None
        try:
            form = CustomerForm(request.POST, instance=Customer.objects.get(id=request.GET['id']))
        except:
            form = CustomerForm(request.POST)

        if form.is_valid():
            form.save()
            return HttpResponse(status=204, headers={'HX-Trigger': 'listChanged'})

        context={'form':form}
        return render(request=request, template_name="view_form.html", context=context)

class BookingListView(TemplateView):
    def get(self, request):
        pageinfo = {'title': 'Booking', 'edituri': 'booking-edit', 'datauri': 'booking-data'}
        context = {'pageinfo': pageinfo, 'list': Booking.objects.all()}
        return render(request=request,template_name=self.template_name, context=context)

class BookingView(View):
    def calc_invoice(self, booking):
        booking.baserate = 500
        booking.discount = 10
        booking.surcharge = 20
        subtotal = booking.baserate - booking.discount + booking.surcharge
        booking.cgst = subtotal * 0.09
        booking.sgst = subtotal * 0.09
        booking.amount = subtotal + booking.cgst + booking.sgst
        booking.save()

    def get(self, request):
        form = None
        try:
            form = BookingForm(instance=Booking.objects.get(id=request.GET['id']))
        except:
            form = BookingForm()

        context = {'form': form}
        return render(request=request,template_name="booking.html", context=context)
        
    def post(self, request):
        form = None
        try:
            form = BookingForm(request.POST, instance=Booking.objects.get(id=request.GET['id']))
        except:
            form = BookingForm(request.POST)

        if form.is_valid():
            form.save()
            self.calc_invoice(Booking.objects.get(id=form.instance.id))
            return HttpResponse(status=204, headers={'HX-Trigger': 'listChanged'})

        context={'form':form}
        return render(request=request, template_name="booking.html", context=context)
   
class ServiceView(View):
    def get(self, request):
        form = None
        try:
            form = ServiceForm(instance=Booking.objects.get(id=request.GET['id']))
        except:
            return redirect("booking")
        
        context = {'form': form, 'list': Booking.objects.all()}
        return render(request=request,template_name="service.html", context=context)

    def post(self, request):
        form = None
        try:
            form = ServiceForm(request.POST, instance=Booking.objects.get(id=request.GET['id']))
        except:
            return redirect("booking")

        if form.is_valid():
            form.save()
            return redirect("service")

        context={'form':form,'list': Booking.objects.all()}
        return render(request=request, template_name="service.html", context=context)
    
class PaymentView(View):
    def get(self, request):
        form = None
        try:
            form = PaymentForm(instance=Booking.objects.get(id=request.GET['id']))
        except:
            return redirect("booking")
        
        context = {'form': form, 'list': Booking.objects.all()}
        return render(request=request,template_name="payment.html", context=context)

    def post(self, request):
        form = None
        try:
            form = PaymentForm(request.POST, instance=Booking.objects.get(id=request.GET['id']))
        except:
            return redirect("booking")

        if form.is_valid():
            form.save()
            return redirect("payment")

        context={'form':form,'list': Booking.objects.all()}
        return render(request=request, template_name="payment.html", context=context)

class InvoiceView(View):
    def get(self, request):
        form = None
        try:
            form = InvoiceForm(instance=Booking.objects.get(id=request.GET['id']))
        except:
            return redirect("booking")
        
        context = {'form': form, 'list': Booking.objects.all()}
        return render(request=request,template_name="invoice.html", context=context)

    def post(self, request):
        form = None
        try:
            form = InvoiceForm(request.POST, instance=Booking.objects.get(id=request.GET['id']))
        except:
            return redirect("booking")

        if form.is_valid():
            form.save()
            return redirect("invoice")

        context={'form':form,'list': Booking.objects.all()}
        return render(request=request, template_name="invoice.html", context=context)

