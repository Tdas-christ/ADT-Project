from django.db import models
from datetime import date
from django.core.validators import MaxValueValidator
from django.core.validators import MinValueValidator
from django.core.validators import EmailValidator
from django.contrib.auth.hashers import make_password, check_password

# Create your models here.

class User(models.Model):
    name = models.CharField(max_length=100,  null=True, blank=False, help_text="Full name")
    email = models.EmailField(max_length=100,  null=True, blank=False, help_text="Email address")
    phone_number = models.CharField(max_length=10,null=True,blank=False, help_text="Phone number")
    password = models.CharField(max_length=128, null=True, blank=False, help_text="Password")

    def set_password(self, raw_password):
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def __str__(self):
        return self.name

     
    class Meta:
        db_table="user"

# Vehicle definition
class Vehicle(models.Model):
    make_choices = (
        ("mahindra", "Mahindra"),
        ("tata", "Tata"),
        ("suzuki", "Suzuki"),
        ("toyota", "Toyota"),
        ("renault", "Renault"),
        ("kia", "Kia"),
        ("hyundai", "Hyundai"),
        ("honda", "Honda"),
        ("force", "Force"),
        ("bmw", "BMW"),
        ("mercedes", "Mercedes"),
        ("audi", "Audi"),
        ("chevrolet", "Chevrolet"),
        ("isuzu", "Isuzu"),
        ("nissan", "Nissan"),
        ("volkswagen", "Volkswagen"),
        ("volvo", "Volvo"),
        ("datsun", "Datsun"),
        ("jeep", "Jeep"),
        ("porche", "Porche"),
        ("citrogen", "Citrogen"),
        ("skoda", "Skoda"),
        ("mini", "Mini"),
        ("lexus", "Lexus"),
        ("jaguar", "Jaguar"),
        ("rover", "Rover")
        )
    category_choices = (
        ("eco", "Economy"),
        ("mid", "Midsize / Hatchback"),
        ("ful", "Fullsize Sedan"),
        ("suv", "Sports and Utility"),
        ("lux", "Luxury"),
        ("off", "Offroader 4x4"),
        ("pup", "Pickup 4x4")
        )
    name = models.CharField("Name", max_length=32, null=False, blank=False, help_text="Name or model e.g. Scorpio")
    make = models.CharField("Make", max_length=16, default="mahindra", choices = make_choices, null=False, blank=False, help_text="Manufacturer e.g. Mahindra")
    category = models.CharField("Category", max_length=3, default="eco", choices=category_choices, null=False, blank=False, help_text="Type of vehicle e.g. Sports and Utility")

    def __str__(self):
        return self.get_make_display() + " " + self.name + " (" + self.get_category_display() + ")"
    
    class Meta:
        db_table = "vehicle"

# Place as source and destination
class Place(models.Model): 
    state_choices = (
        ("AP","Andhra Pradesh"),
        ("AR","Arunachal Pradesh "),
        ("AS","Assam"),
        ("BR","Bihar"),
        ("CT","Chhattisgarh"),
        ("GA","Goa"),
        ("GJ","Gujarat"),
        ("HR","Haryana"),
        ("HP","Himachal Pradesh"),
        ("JK","Jammu and Kashmir "),
        ("JH","Jharkhand"),
        ("KA","Karnataka"),
        ("KL","Kerala"),
        ("MP","Madhya Pradesh"),
        ("MH","Maharashtra"),
        ("MN","Manipur"),
        ("ML","Meghalaya"),
        ("MZ","Mizoram"),
        ("NL","Nagaland"),
        ("OR","Odisha"),
        ("PB","Punjab"),
        ("RJ","Rajasthan"),
        ("SK","Sikkim"),
        ("TN","Tamil Nadu"),
        ("TG","Telangana"),
        ("TR","Tripura"),
        ("UP","Uttar Pradesh"),
        ("UK","Uttarakhand"),
        ("WB","West Bengal"),
        ("AN","Andaman and Nicobar Islands"),
        ("CG","Chandigarh"),
        ("DN","Dadra and Nagar Haveli"),
        ("DD","Daman and Diu"),
        ("LD","Lakshadweep"),
        ("DL","Delhi"),
        ("PY","Puducherry")
        )
    name = models.CharField("Name", max_length=32, null=False, blank=False, help_text="Name of the place e.g. Gangtok")
    state = models.CharField("State", max_length=2, default="AN", choices = state_choices, null=False, blank=False, help_text="State e.g. Sikkim")

    def __str__(self):
        return self.name + " (" + self.state + ")"
    
    class Meta:
        db_table = "place"

# Trip as a journey from one location to another location
class Trip(models.Model):
    pickup = models.ForeignKey(Place, on_delete=models.CASCADE, null=False, blank=False, help_text="Pickup location e.g. Siliguri", related_name="pickup")
    dropoff = models.ForeignKey(Place, on_delete=models.CASCADE, null=False, blank=False, help_text="Destination e.g. Pelling", related_name="dropoff")
    distance = models.IntegerField("Distance (Km)", null=False, blank=False, validators=[MinValueValidator(limit_value= 1)], help_text="Approximate distance in Km")
    duration = models.IntegerField("Time (Min)", null=False, blank=False, validators=[MinValueValidator(limit_value= 1)], help_text="Approximate duration of the trip e.g. 60min")

    def __str__(self):
        return str(self.pickup) + " to " + str(self.dropoff)
    
    class Meta:
        db_table = "trip"
        unique_together = ('pickup', 'dropoff',)

# Rate for a trip in different type of vehicles
class Rate(models.Model):
    trip = models.ForeignKey(Trip, on_delete=models.CASCADE, null=False, blank=False, unique=True)
    eco = models.DecimalField("Economy", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="Base rate")
    mid = models.DecimalField("Midsize  / Hatchback", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="Base rate")
    ful = models.DecimalField("Fullsize Sedan", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="Base rate")
    suv = models.DecimalField("Sports & Utility", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="Base rate")
    lux = models.DecimalField("Luxury", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="Base rate")
    off = models.DecimalField("Offroader 4x4", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="Base rate")
    pup = models.DecimalField("Pickup 4x4", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="Base rate")

    def __str__(self):
        return str(self.trip)
 
    class Meta:
        db_table = "rate"

# Discounts and additional fees and surcharges
class Discount(models.Model):
    disctype_choices = (
        ("perc", "Percentage"),
        ("flat", "Flat")
    )
    name = models.CharField("Name", max_length=32, null=False, blank=False, help_text="Name of discount or surcharge e.g. Weekend Discount or Transaction Fee")
    eff_from = models.DateField("From", null=False, blank=False, validators=[MinValueValidator(limit_value= date.today)], help_text="Discount / surcharge effective from")
    eff_till = models.DateField("Till", null=True, blank=True, validators=[MinValueValidator(limit_value= date.today)], help_text="Discount / surcharge effective up till")
    discount = models.DecimalField("Disc/Schg (%)", max_digits=5, decimal_places=2, null=True, blank=True, default=0.0, help_text="Value in percentage or absolute amount. Negative for discount and positive for surcharge")
    disctype = models.TextField("Disc/Schg Type", max_length=16, default="perc", choices=disctype_choices, null=True, blank=True, help_text="Whether the discount is in percentage or flat amount")
    eco = models.BooleanField("Economy", null=False, blank=False, default=False, help_text="True for applicable")
    mid = models.BooleanField("Midsize  / Hatchback", null=False, blank=False, default=False, help_text="True for applicable")
    ful = models.BooleanField("Fullsize Sedan", null=False, blank=False, default=False, help_text="True for applicable")
    suv = models.BooleanField("Sports & Utility", null=False, blank=False, default=False, help_text="True for applicable")
    lux = models.BooleanField("Luxury", null=False, blank=False, default=False, help_text="True for applicable")
    off = models.BooleanField("Offroader 4x4", null=False, blank=False, default=False, help_text="True for applicable")
    pup = models.BooleanField("Pickup 4x4", null=False, blank=False, default=False, help_text="True for applicable")

    def __str__(self):
        return self.name

    class Meta:
        db_table = "discount"

# Customer who is making the booking and paying
class Customer(models.Model):
    name = models.CharField("Name", max_length=32, null=False, blank=False, help_text="Full name")
    phone = models.CharField("Mobile", max_length=32, null=False, blank=False, help_text="Phone number of customer5")
    email = models.CharField("Email", max_length=32, null=False, blank=False, validators=[EmailValidator()], help_text="Email address of customer")
    gstin = models.CharField("GSTIN", max_length=16, null=True, blank=True, help_text="GST number if available")

    def __str__(self):
        return self.name

    class Meta:
        db_table = "customer"

# The actual booking record of a customer for a trip on a date
class Booking(models.Model):
    status_choices = (
        ("active", "Active"),
        ("canceled", "Canceled"),
    )
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, null=False, blank=False)
    trip = models.ForeignKey(Trip, on_delete=models.CASCADE, null=False, blank=False)
    vehicle = models.ForeignKey(Vehicle, on_delete=models.CASCADE, null=False, blank=False)
    booking_date = models.DateTimeField("Booking Date", null=False, blank=False, default=date.today, validators=[MaxValueValidator(limit_value= date.today)], help_text="Date of transaction")
    journey_date = models.DateField("Journey date", null=False, blank=False, validators=[MinValueValidator(limit_value= date.today)], help_text="Date of journey")

    vehicle_number = models.CharField("Vehicle Number", max_length=32, null=True, blank=True, help_text="Vehicle number assigned")
    driver_name = models.CharField("Driver Name", max_length=32, null=True, blank=True, help_text="Driver information")
    driver_contact = models.CharField("Driver Contact", max_length=256, null=True, blank=True, help_text="Driver information")
    status = models.TextField("Status", max_length=16, default="active", choices=status_choices, null=False, blank=False)

    paymode_choices = (
        ("cash", "Cash"),
        ("card", "Debit / Credit Card"),
        ("upi", "UPI"),
    )
    paymode = models.TextField("Payment Mode", max_length=8, default="card", choices=paymode_choices, null=True, blank=True, help_text="Mode of payment e.g. Card, Cash etc.")
    payref = models.CharField("Payment Ref", max_length=32, null=True, blank=True, help_text="Payment transaction reference number. N/A for cash")
    paid = models.BooleanField("Paid", null=False, blank=False, default=False, help_text="Is paid?")

    """
    This is how amount should be calculated:
    ----------------------------------------
    get the base rate from Rate using selected trip and vehicle
    get all the discounts / surcharges applicable from Discount using selected vehicle.type and journey_date;
    there may be multiple rows effective for the given date and vehicle type
    calculate total discount amount by applying all the values which are negative
    if disctype is percentage then discount = discount + baserate * Discount.discount
    if the disctype is flat then the discount = discount + Discount.discount
    calculate the surcharge amount by applying all the values which are positive
    if disctype is percentage then surcharge = surcharge + baserate * Discount.discount
    if the disctype is flat then the surcharge = surcharge + Discount.discount
    net_amount = baserate - discount + surcharge
    cgst = net_amount * 0.09
    sgst = net_amount * 0.09
    payment = net_amount + cgst + sgst
    """
    baserate = models.DecimalField("Base", max_digits=8, decimal_places=2, null=True, blank=True, help_text="Base rate from pre defined rates")
    discount = models.DecimalField("Discount", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="Total discount")
    surcharge = models.DecimalField("Surcharge", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="Total surcharge")
    cgst = models.DecimalField("CGST", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="Central GST")
    sgst = models.DecimalField("SGST", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="State GST")
    amount = models.DecimalField("Amount", max_digits=8, decimal_places=2, null=True, blank=True, default=0.0, help_text="Total amount paid")

    def __str__(self):
        return str(self.customer) + "/" + str(self.trip) + "/" + str(self.journey_date)
    
    class Meta:
        db_table = "booking"
   
# record of refunds payment in case the booking is canceled
class Refund(models.Model):
    status_choices = (
        ("pending", "Pending"),
        ("done", "Done")
    )
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, null=False, blank=False)
    """
    status should be manually changed from pending to done.
    Once the status is changed to done it cannot be reversed
    while changing the status ensure that the booking status is canceled. otherwise refuse
    """
    status = models.TextField("Status", max_length=16, default="pending", choices=status_choices, null=False, blank=False)
    payref = models.CharField(name="Payment Mode", max_length=32, null=True, blank=True, help_text="Payment transaction reference number. N/A for cash")

    class Meta:
        db_table = "refund"
