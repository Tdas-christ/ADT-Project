from django.urls import path
from . import views
from core.views import signup


urlpatterns = [
 path('', views.BookingListView.as_view(template_name="view_list.html"), name='home'),
 

    path('intercity/booking/data', views.BookingListView.as_view(template_name="data_booking.html"), name='booking-data'),
    path('intercity/booking/list', views.BookingListView.as_view(template_name="view_list.html"), name='booking-list'),
    path('intercity/booking/edit', views.BookingView.as_view(), name='booking-edit'),

    path('intercity/customer/data', views.CustomerListView.as_view(template_name="data_customer.html"), name='customer-data'),
    path('intercity/customer/list', views.CustomerListView.as_view(template_name="view_list.html"), name='customer-list'),
    path('intercity/customer/edit', views.CustomerView.as_view(), name='customer-edit'),

    path('intercity/vehicle/data', views.VehicleListView.as_view(template_name="data_vehicle.html"), name='vehicle-data'),
    path('intercity/vehicle/list', views.VehicleListView.as_view(template_name="view_list.html"), name='vehicle-list'),
    path('intercity/vehicle/edit', views.VehicleView.as_view(), name='vehicle-edit'),

    path('intercity/place/data', views.PlaceListView.as_view(template_name="data_place.html"), name='place-data'),
    path('intercity/place/list', views.PlaceListView.as_view(template_name="view_list.html"), name='place-list'),
    path('intercity/place/edit', views.PlaceView.as_view(), name='place-edit'),

    path('intercity/trip/data', views.TripListView.as_view(template_name="data_trip.html"), name='trip-data'),
    path('intercity/trip/list', views.TripListView.as_view(template_name="view_list.html"), name='trip-list'),
    path('intercity/trip/edit', views.TripView.as_view(), name='trip-edit'),

    path('intercity/rate/data', views.RateListView.as_view(template_name="data_rate.html"), name='rate-data'),
    path('intercity/rate/list', views.RateListView.as_view(template_name="view_list.html"), name='rate-list'),
    path('intercity/rate/edit', views.RateView.as_view(), name='rate-edit'),

    path('intercity/discount/data', views.DiscountListView.as_view(template_name="data_discount.html"), name='discount-data'),
    path('intercity/discount/list', views.DiscountListView.as_view(template_name="view_list.html"), name='discount-list'),
    path('intercity/discount/edit', views.DiscountView.as_view(), name='discount-edit'),

    path('intercity/invoice', views.InvoiceView.as_view(), name='invoice'),
    path('intercity/service', views.ServiceView.as_view(), name='service'),
    path('intercity/payment', views.PaymentView.as_view(), name='payment'),
]