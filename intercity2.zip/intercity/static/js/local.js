function open_form(link, id) {
    let uri = (id)? (link + '?id=' + id) : link;
    document.location = uri;
}